import json
import os
from pathlib import Path
import socket
import subprocess
import tempfile
from datetime import datetime, timezone

root = Path.cwd()
evidence = root / 'var/validation-20261019'
temp = Path(tempfile.mkdtemp(prefix='zhixue-g1-20261019-'))
postgres = temp / 'postgres'
redis = Path('/tmp/zhixue-g1-redis-20261019/redis-7.4.2/src')
pg_started = redis_started = False
result = {'source_head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
          'temporary_cluster': str(temp), 'postgres_port': 54339, 'redis_port': 6389,
          'started': datetime.now(timezone.utc).isoformat()}
try:
    for port in (54339, 6389, 3410, 3411, 3412, 3413):
        with socket.socket() as check:
            check.bind(('127.0.0.1', port))
    subprocess.run(['initdb', '-D', str(postgres), '-U', 'zhixue_bootstrap', '-A', 'trust', '--no-locale', '-E', 'UTF8'], check=True)
    subprocess.run(['pg_ctl', '-D', str(postgres), '-l', str(evidence / 'postgres.log'), '-o', f'-h 127.0.0.1 -p 54339 -k {temp}', '-w', 'start'], check=True)
    pg_started = True
    subprocess.run([str(redis / 'redis-server'), '--bind', '127.0.0.1', '--port', '6389', '--save', '', '--appendonly', 'no', '--dir', str(temp), '--daemonize', 'yes', '--pidfile', str(temp / 'redis.pid'), '--logfile', str(evidence / 'redis.log')], check=True)
    redis_started = True
    env = {**os.environ, 'ZHIXUE_PROFILE': 'local', 'PGPORT': '54339', 'REDIS_PORT': '6389'}
    result['command'] = 'ZHIXUE_PROFILE=local PGPORT=54339 REDIS_PORT=6389 node scripts/run-isolated.mjs'
    result['versions'] = {name: subprocess.check_output(command, text=True).strip() for name, command in {
        'node': ['node', '--version'], 'python': ['.venv/bin/python', '--version'],
        'postgres': ['postgres', '--version'], 'redis': [str(redis / 'redis-server'), '--version']}.items()}
    before = set((root / 'var/runs').iterdir())
    with (evidence / 'local-suite.log').open('w') as log:
        result['exit_code'] = subprocess.run(['node', 'scripts/run-isolated.mjs'], env=env, stdout=log, stderr=subprocess.STDOUT).returncode
    result['runs'] = [str(path.relative_to(root)) for path in set((root / 'var/runs').iterdir()) - before]
finally:
    if redis_started:
        subprocess.run([str(redis / 'redis-cli'), '-h', '127.0.0.1', '-p', '6389', 'shutdown', 'nosave'], check=True)
    if pg_started:
        subprocess.run(['pg_ctl', '-D', str(postgres), '-w', 'stop', '-m', 'fast'], check=True)
    result['ended'] = datetime.now(timezone.utc).isoformat()
    (evidence / 'local-run.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))
raise SystemExit(result.get('exit_code', 1))
