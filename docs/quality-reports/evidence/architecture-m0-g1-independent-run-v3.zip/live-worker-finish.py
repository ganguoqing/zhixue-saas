"""Calls the unchanged Worker.finish against the isolated real API and mock provider."""
import asyncio,importlib.util,json,os,sys,traceback
import httpx
spec=importlib.util.spec_from_file_location('review_worker','apps/worker/worker.py')
w=importlib.util.module_from_spec(spec);spec.loader.exec_module(w)
async def main():
 payload=json.load(sys.stdin)
 async with httpx.AsyncClient(timeout=10,trust_env=False) as client:
  try:
   result=await w.finish(client,payload['data'],payload['claimed'])
   print(json.dumps({'result':result,'exception':None}))
  except Exception as e:
   traceback.print_exc()
   print(json.dumps({'exception':type(e).__name__,'message':str(e)}))
asyncio.run(main())
