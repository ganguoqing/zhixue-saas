import pg from'pg';import{randomUUID}from'node:crypto';import{writeFileSync}from'node:fs';import assert from'node:assert/strict';import{loadDevEnv,roleUrl}from'./scripts/lib.mjs';loadDevEnv();
const A='11111111-1111-4111-8111-111111111111';const c=new pg.Client({connectionString:roleUrl('zhixue_ai_ingress','ZHIXUE_INGRESS_PASSWORD')});await c.connect();const out=[];
await c.query('BEGIN');await c.query("SELECT set_config('app.tenant_id',$1,true)",[A]);const jobs=(await c.query('SELECT id,current_attempt_id FROM zhixue.processing_jobs WHERE current_attempt_id IS NOT NULL AND tenant_id=$1 ORDER BY id LIMIT 2',[A])).rows;await c.query('ROLLBACK');assert.equal(jobs.length,2);
for(const t of [{name:'nonexistent_job_and_attempt',job:randomUUID(),attempt:randomUUID(),epoch:1},{name:'attempt_belongs_to_different_job',job:jobs[0].id,attempt:jobs[1].current_attempt_id,epoch:1},{name:'nonpositive_epoch_and_generation',job:jobs[0].id,attempt:jobs[0].current_attempt_id,epoch:0,generation:0}]){
 await c.query('BEGIN');await c.query("SELECT set_config('app.tenant_id',$1,true)",[A]);
 const attempt=t.name==='nonpositive_epoch_and_generation'?randomUUID():t.attempt;
 if(t.name==='attempt_belongs_to_different_job'){
  // The same attempt is UNIQUE. Update the existing intent to the other real job instead of duplicating it.
  const r=await c.query('UPDATE zhixue.delivery_intents SET job_id=$1 WHERE tenant_id=$2 AND attempt_id=$3',[t.job,A,attempt]);assert.equal(r.rowCount,1);out.push({name:t.name,result:'accepted',context:A,changed:r.rowCount,rolledBack:true});
 }else if(t.name==='nonpositive_epoch_and_generation'){
  const r=await c.query('UPDATE zhixue.delivery_intents SET fencing_epoch=0,generation=0 WHERE tenant_id=$1 AND attempt_id=$2',[A,t.attempt]);assert.equal(r.rowCount,1);out.push({name:t.name,result:'accepted',context:A,changed:r.rowCount,parentsValid:true,rolledBack:true});
 }else{
  const r=await c.query(`INSERT INTO zhixue.delivery_intents(tenant_id,id,job_id,attempt_id,fencing_epoch,stage,billable,lease_token,generation,input_hash) VALUES($1,$2,$3,$4,$5,'model_grade',true,'synthetic-credential',$6,$7)`,[A,randomUUID(),t.job,attempt,t.epoch,t.generation??1,'ab'.repeat(32)]);out.push({name:t.name,result:'accepted',context:A,inserted:r.rowCount,rolledBack:true});
 }
 await c.query('ROLLBACK');
}
await c.end();writeFileSync('var/runs/reviewer/fk-probe.json',JSON.stringify(out,null,2));console.log(JSON.stringify(out,null,2));
