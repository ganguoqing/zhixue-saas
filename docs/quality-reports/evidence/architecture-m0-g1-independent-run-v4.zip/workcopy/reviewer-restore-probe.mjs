import pg from 'pg';import {spawn} from 'node:child_process';import {readFileSync,writeFileSync} from 'node:fs';import{loadDevEnv,roleUrl}from'./scripts/lib.mjs';loadDevEnv();
const target='zhixue_m0_g1reviewv4restore_20261014';
const replace=(url)=>url.replace('/'+process.env.PGDATABASE,'/'+target);
const admin=new pg.Client({connectionString:roleUrl('zhixue_bootstrap','BOOTSTRAP_PASSWORD').replace('/'+process.env.PGDATABASE,'/postgres')});await admin.connect();
if((await admin.query('SELECT 1 FROM pg_database WHERE datname=$1',[target])).rowCount)throw Error('refuse existing DB');
await admin.query(`CREATE DATABASE ${target}`);await admin.query(`GRANT CREATE ON DATABASE ${target} TO zhixue_migrator`);await admin.end();
const ext=new pg.Client({connectionString:replace(roleUrl('zhixue_bootstrap','BOOTSTRAP_PASSWORD'))});await ext.connect();await ext.query('CREATE EXTENSION pgcrypto');await ext.end();
let output='';const exitCode=await new Promise((resolve,reject)=>{const p=spawn('/Users/johnny/.homebrew/opt/postgresql@17/bin/pg_restore',['--no-owner','-d',target,'var/runs/reviewer/upgrade.dump'],{env:{...process.env,PGDATABASE:target,PGUSER:'zhixue_migrator',PGPASSWORD:process.env.ZHIXUE_MIGRATOR_PASSWORD}});p.stdout.on('data',b=>output+=b);p.stderr.on('data',b=>output+=b);p.on('exit',resolve);p.on('error',reject);});
writeFileSync('var/runs/reviewer/exact-restore.log',output);
const c=new pg.Client({connectionString:replace(roleUrl('zhixue_migrator','ZHIXUE_MIGRATOR_PASSWORD'))});await c.connect();
const functions=(await c.query(`SELECT p.proname,pg_get_userbyid(p.proowner) owner,r.rolbypassrls FROM pg_proc p JOIN pg_namespace n ON n.oid=p.pronamespace JOIN pg_roles r ON r.oid=p.proowner WHERE n.nspname='zhixue_ctl' AND p.prosecdef ORDER BY p.proname`)).rows;
let migration;
await c.query('BEGIN');try{await c.query(readFileSync('db/migrations/0006_g1_v3_delivery.sql','utf8'));await c.query('COMMIT');migration={passed:true};}catch(e){await c.query('ROLLBACK');migration={passed:false,code:e.code,message:e.message};}finally{await c.query('RESET ROLE');}
const out={target,pgRestoreExit:exitCode,restoreLog:output,original0006:migration,securityDefinerFunctions:functions,oldJobs:(await c.query('SELECT status,result_status FROM zhixue.processing_jobs')).rows};
await c.end();writeFileSync('var/runs/reviewer/restore-probe.json',JSON.stringify(out,null,2));console.log(JSON.stringify(out,null,2));
