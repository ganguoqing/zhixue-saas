import pg from 'pg';
import assert from 'node:assert/strict';
import {randomUUID} from 'node:crypto';
import {writeFileSync} from 'node:fs';
import {loadDevEnv,roleUrl} from './scripts/lib.mjs';
loadDevEnv();
const out={time:new Date().toISOString(),tests:[]};
const A='11111111-1111-4111-8111-111111111111';
const B='22222222-2222-4222-8222-222222222222';
for(const [role,key] of [['zhixue_ai_ingress','ZHIXUE_INGRESS_PASSWORD'],['zhixue_reconciler','ZHIXUE_RECONCILER_PASSWORD']]){
 const c=new pg.Client({connectionString:roleUrl(role,key)});await c.connect();
 const flags=await c.query("SELECT relrowsecurity,relforcerowsecurity,pg_get_userbyid(relowner) owner FROM pg_class WHERE oid='zhixue.delivery_intents'::regclass");
 const counts=[];
 for(const t of [A,B,'']){
  await c.query('BEGIN');await c.query("SELECT set_config('app.tenant_id',$1,true)",[t]);
  const q=await c.query('SELECT count(*)::int total,count(*) FILTER (WHERE tenant_id=$1)::int tenant_a_rows,count(*) FILTER (WHERE length(lease_token)>0)::int credentials FROM zhixue.delivery_intents',[A]);
  counts.push({context:t||'none',...q.rows[0]});await c.query('ROLLBACK');
 }
 await c.query('BEGIN');await c.query("SELECT set_config('app.tenant_id',$1,true)",[B]);
 const changed=await c.query("UPDATE zhixue.delivery_intents SET state='pending' WHERE tenant_id=$1 RETURNING id",[A]);
 await c.query('ROLLBACK');
 await c.query('BEGIN');await c.query("SELECT set_config('app.tenant_id',$1,true)",[B]);
 const fake=randomUUID();
 await c.query(`INSERT INTO zhixue.delivery_intents(tenant_id,id,job_id,attempt_id,fencing_epoch,stage,billable,lease_token,generation,input_hash) VALUES($1,$2,$3,$4,1,'model_grade',true,'synthetic-no-secret',1,$5)`,[A,fake,randomUUID(),randomUUID(),'ab'.repeat(32)]);
 await c.query('ROLLBACK');
 assert(flags.rows[0].relrowsecurity===false);
 assert(counts.every(x=>x.tenant_a_rows>0));assert(changed.rowCount>0);
 out.tests.push({role,flags:flags.rows[0],counts,crossTenantUpdateRows:changed.rowCount,crossTenantMissingJobInsert:'accepted_and_rolled_back'});
 await c.end();
}
writeFileSync('var/runs/reviewer/rls-probe.json',JSON.stringify(out,null,2));
console.log(JSON.stringify(out,null,2));
