import asyncio
import os
import time

import httpx
import jwt
from bullmq import Worker


def service_token(scope: str, job_id: str | None = None, attempt_id: str | None = None) -> str:
    payload = {
        "scope": scope,
        "iss": "zhixue-worker",
        "sub": "svc:worker",
        "aud": "zhixue-internal",
        "iat": int(time.time()),
        "exp": int(time.time()) + 60,
        "jti": os.urandom(16).hex(),
    }
    if job_id:
        payload["job_id"] = job_id
    if attempt_id:
        payload["attempt_id"] = attempt_id
    return jwt.encode(payload, os.environ["WORKER_JWT_SECRET"], algorithm="HS256")


def headers(scope: str, job_id: str | None = None, attempt_id: str | None = None, idempotency_key: str | None = None) -> dict[str, str]:
    result = {"authorization": f"Bearer {service_token(scope, job_id, attempt_id)}"}
    if idempotency_key:
        result["idempotency-key"] = idempotency_key
    return result


async def finish(client: httpx.AsyncClient, data: dict, claimed: dict) -> dict:
    api = os.environ["API_BASE"]
    job_id = data["jobId"]
    attempt_id = claimed["attemptId"]
    if data.get("killAfterClaim"):
        os.kill(os.getpid(), 9)
    if data.get("billable"):
        prepared = await client.post(
            f"{api}/internal/jobs/prepare-invocation",
            json={"jobId": job_id, "attemptId": attempt_id},
            headers=headers("ai.job.prepare_invocation", job_id, attempt_id),
        )
        prepared.raise_for_status()
        invocation_id = prepared.json()["id"]
        if prepared.json().get("send_state") == "not_sent":
            permit = await client.post(
                f"{api}/internal/jobs/issue-send-permit",
                json={"jobId": job_id, "attemptId": attempt_id, "invocationId": invocation_id},
                headers=headers("ai.invocation.issue_permit", job_id, attempt_id),
            )
            if permit.status_code >= 400:
                print(f"permit_rejected job_id={job_id} status={permit.status_code}", flush=True)
                return {"permit_rejected": permit.status_code}
            if data.get("killAfterPermit"):
                os.kill(os.getpid(), 9)
        frozen = await client.get(
            f"{api}/internal/jobs/{job_id}/frozen",
            headers=headers("ai.job.read_frozen", job_id),
        )
        frozen.raise_for_status()
        fixture = frozen.json()
        try:
            inferred = await client.post(
                f"{os.environ['INFERENCE_URL']}/infer",
                json={
                    "job_id": job_id,
                    "input_hash": claimed["inputHash"],
                    "stage": "model_grade",
                    "delay_seconds": data.get("delaySeconds"),
                    "sample": data.get("sample"),
                    "mode": data.get("providerMode"),
                    "asset_id": fixture.get("assetId"),
                    "questions": fixture.get("questions"),
                },
                timeout=0.5 if data.get("delaySeconds") else 5,
            )
        except httpx.TimeoutException:
            print(f"provider_timeout job_id={job_id}", flush=True)
            return {"send_unknown": True}
        if data.get("killAfterHttp"):
            os.kill(os.getpid(), 9)
        observed = await client.post(
            f"{api}/internal/jobs/record-observation",
            json={
                "jobId": job_id,
                "attemptId": attempt_id,
                "invocationId": invocation_id,
                "providerStatus": inferred.status_code,
            },
            headers=headers("ai.invocation.observe", job_id, attempt_id),
        )
        observed.raise_for_status()
        if inferred.status_code >= 400:
            return await accept(client, data, claimed, False, None, "provider_error")
        try:
            body = inferred.json()
        except ValueError:
            return await accept(client, data, claimed, False, None, "bad_json")
        envelope = {
            "schema_version": "acceptance-envelope/1.0.0",
            "job_id": job_id,
            "attempt_id": attempt_id,
            "generation": claimed["generation"],
            "fencing_epoch": claimed["fencingEpoch"],
            "lease_token": claimed["leaseToken"],
            "input_hash": claimed["inputHash"],
            "invocation_id": invocation_id,
            "payload": {
                "schema_version": "model-grade-payload/1.0.0",
                "items": body.get("items") or [],
            },
        }
        return await accept(client, data, claimed, True, envelope, "accepted")
    inferred = await client.post(
        f"{os.environ['INFERENCE_URL']}/infer",
        json={
            "job_id": job_id,
            "input_hash": claimed["inputHash"],
            "stage": "validate_asset",
            "sample": data.get("sample"),
            "mode": data.get("providerMode"),
        },
        timeout=5,
    )
    outcome = None
    ok = False
    if inferred.status_code < 400:
        try:
            body = inferred.json()
            if body.get("outcome") == "accepted" and body.get("input_hash") == claimed["inputHash"]:
                ok = True
                outcome = "accepted"
        except ValueError:
            ok = False
    return await accept(client, data, claimed, ok, None, outcome)


async def accept(client, data, claimed, ok, envelope, outcome):
    accepted = await client.post(
        f"{os.environ['API_BASE']}/internal/jobs/accept",
        json={
            "jobId": data["jobId"],
            "attemptId": claimed["attemptId"],
            "fencingEpoch": claimed["fencingEpoch"],
            "leaseToken": claimed["leaseToken"],
            "generation": claimed["generation"],
            "inputHash": claimed["inputHash"],
            "ok": ok,
            "outcome": outcome,
            "envelope": envelope,
        },
        headers=headers("ai.result.accept", data["jobId"], claimed["attemptId"], f"accept:{claimed['attemptId']}"),
    )
    if accepted.status_code >= 400:
        print(f"accept_rejected job_id={data['jobId']} status={accepted.status_code} body={accepted.text[:200]}", flush=True)
        return {"rejected": accepted.status_code}
    print(f"accepted job_id={data['jobId']}", flush=True)
    return accepted.json()


async def process(job, _token):
    data = job.data or {}
    api = os.environ["API_BASE"]
    print(f"received job_id={data.get('jobId')} action={data.get('action', 'execute')}", flush=True)
    async with httpx.AsyncClient(timeout=10, trust_env=False) as client:
        if data.get("action") == "takeover":
            return {"ignored": True, "reason": "takeover_is_reconciler"}
        claim = await client.post(
            f"{api}/internal/jobs/claim",
            json={"jobId": data["jobId"], "capability": data.get("capability")},
            headers=headers("ai.job.claim", data.get("jobId")),
        )
        if claim.status_code >= 400:
            print(f"claim_rejected job_id={data.get('jobId')} status={claim.status_code} body={claim.text[:300]}", flush=True)
            return {"ignored": True, "status": claim.status_code}
        claimed = claim.json()
        if claimed.get("status") == "failed_final":
            return claimed
        return await finish(client, data, claimed)


async def main() -> None:
    worker = Worker(
        "zhixue-jobs",
        process,
        {
            "connection": {
                "host": os.environ["REDIS_HOST"],
                "port": int(os.environ["REDIS_PORT"]),
                "db": int(os.environ.get("REDIS_DB", "0")),
            },
            "prefix": os.environ.get("QUEUE_PREFIX", "zhixue"),
            "concurrency": 8,
        },
    )
    try:
        while True:
            await asyncio.sleep(1)
    finally:
        await worker.close()


if __name__ == "__main__":
    asyncio.run(main())
