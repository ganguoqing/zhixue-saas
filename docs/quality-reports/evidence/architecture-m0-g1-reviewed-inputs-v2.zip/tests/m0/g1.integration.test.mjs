import { spawn } from 'node:child_process';
import { createWriteStream, mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { randomUUID } from 'node:crypto';
import { once } from 'node:events';
import { test } from 'node:test';
import assert from 'node:assert/strict';
import pg from 'pg';
import jwt from 'jsonwebtoken';
import { loadDevEnv, roleUrl } from '../../scripts/lib.mjs';

loadDevEnv();
const database = process.env.PGDATABASE;
const redisDb = process.env.REDIS_DB;
const fileRoot = process.env.FILE_ROOT;
const prefix = process.env.QUEUE_PREFIX;
if (!database?.startsWith('zhixue_m0_g1') || database === 'zhixue_m0') {
  throw new Error(`refusing G1 test on database ${database}`);
}
if (redisDb === '0' || !prefix?.startsWith('zhixue-g1') || !fileRoot?.includes('g1-objects')) {
  throw new Error('refusing G1 test without an isolated Redis DB, queue prefix, and object root');
}

const API = `http://127.0.0.1:${process.env.API_PORT}`;
const A = '11111111-1111-4111-8111-111111111111';
const question = '018f0a3e-7c21-7b2a-8c11-111111111111';
const question2 = '018f0a3e-7c21-7b2a-8c11-111111111112';
const criterion = '018f0a3e-7c21-7b2a-8c11-222222222222';
const python = '.venv/bin/python';
const records = [];
let api;
let inference;
let worker;
let supervisor;

function token(kind, scope, extra = {}) {
  const spec = {
    worker: ['WORKER_JWT_SECRET', 'zhixue-worker', 'svc:worker'],
    reconciler: ['RECONCILER_JWT_SECRET', 'zhixue-reconciler', 'svc:reconciler'],
    scheduler: ['SCHEDULER_JWT_SECRET', 'zhixue-scheduler', 'svc:scheduler'],
    relay: ['RELAY_JWT_SECRET', 'zhixue-relay', 'svc:relay'],
    billing: ['BILLING_JWT_SECRET', 'zhixue-billing', 'svc:billing'],
  }[kind];
  return jwt.sign({
    scope, iss: spec[1], sub: spec[2], jti: randomUUID(), ...extra,
  }, process.env[spec[0]], { audience: 'zhixue-internal', expiresIn: '2m' });
}

function auth(kind, scope, extra) {
  return { authorization: `Bearer ${token(kind, scope, extra)}`, 'content-type': 'application/json' };
}

async function login(email) {
  const response = await fetch(`${API}/api/session`, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ email, password: 'dev-password' }),
  });
  const body = await response.json();
  assert.equal(response.status, 200, JSON.stringify(body));
  return body.token;
}

async function waitHealth(url) {
  for (let attempt = 0; attempt < 50; attempt += 1) {
    try {
      const response = await fetch(url);
      if (response.ok) return;
    } catch {
      // starting
    }
    await new Promise((resolve) => setTimeout(resolve, 200));
  }
  throw new Error(`health timeout ${url}`);
}

function start(name, command, args, logName) {
  const child = spawn(command, args, { env: process.env, stdio: ['ignore', 'pipe', 'pipe'] });
  child.stdout.pipe(createWriteStream(`var/g1-logs/${logName}.log`, { flags: 'a' }));
  child.stderr.pipe(createWriteStream(`var/g1-logs/${logName}.err`, { flags: 'a' }));
  child.on('exit', (code) => records.push({ name: `${name}_exit`, code }));
  return child;
}

async function poll(userToken, jobId) {
  for (let attempt = 0; attempt < 80; attempt += 1) {
    const response = await fetch(`${API}/api/jobs/${jobId}`, { headers: { authorization: `Bearer ${userToken}` } });
    const body = await response.json();
    if (['succeeded', 'failed_final', 'exception_review', 'awaiting_settlement', 'cancelled'].includes(body.status)) return body;
    await new Promise((resolve) => setTimeout(resolve, 250));
  }
  throw new Error(`job ${jobId} did not finish`);
}

test('G1 isolated controls', async () => {
  mkdirSync('var/g1-logs', { recursive: true });
  api = start('api', process.execPath, ['apps/api/dist/main.js'], 'api');
  inference = start('inference', python, ['-m', 'uvicorn', 'apps.inference.main:app', '--host', '127.0.0.1', '--port', process.env.INFERENCE_PORT], 'inference');
  supervisor = start('supervisor', process.execPath, ['apps/api/dist/supervisor.js'], 'supervisor');
  process.env.API_BASE = API;
  worker = start('worker', python, ['apps/worker/worker.py'], 'worker');
  await waitHealth(`${API}/health`);
  await waitHealth(`${process.env.INFERENCE_URL}/health`);

  const tokenA = await login('synthetic-teacher-a@example.test');
  const app = new pg.Client({ connectionString: roleUrl('zhixue_app', 'ZHIXUE_APP_PASSWORD') });
  const ingress = new pg.Client({ connectionString: roleUrl('zhixue_ai_ingress', 'ZHIXUE_INGRESS_PASSWORD') });
  await app.connect();
  await ingress.connect();
  try {

  const seeded = await fetch(`${API}/api/jobs/aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaa3`, {
    headers: { authorization: `Bearer ${tokenA}` },
  });
  assert.equal(seeded.status, 403);
  const cancelSeed = await fetch(`${API}/api/jobs/aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaa3/cancel`, {
    method: 'POST',
    headers: { authorization: `Bearer ${tokenA}` },
  });
  assert.equal(cancelSeed.status, 403);
  records.push({ name: 'out_of_scope', read: seeded.status, cancel: cancelSeed.status });

  const pdf = Buffer.from('%PDF-1.4\nsynthetic-page\n').toString('base64');
  const created = await fetch(`${API}/api/uploads/finalize`, {
    method: 'POST',
    headers: { authorization: `Bearer ${tokenA}`, 'content-type': 'application/json', 'idempotency-key': `g1-${randomUUID()}` },
    body: JSON.stringify({ contentBase64: pdf, classId: 'c1', subjectId: 'math' }),
  });
  const createdBody = await created.json();
  assert.equal(created.status, 200, JSON.stringify(createdBody));
  const finished = await poll(tokenA, createdBody.jobId);
  assert.equal(finished.status, 'succeeded');
  const lateCancel = await fetch(`${API}/api/jobs/${createdBody.jobId}/cancel`, {
    method: 'POST',
    headers: { authorization: `Bearer ${tokenA}` },
  });
  const lateBody = await lateCancel.json();
  assert.equal(lateCancel.status, 409);
  assert.equal(lateBody.error, 'succeeded');
  records.push({ name: 'terminal_cancel', status: lateCancel.status, error: lateBody.error });

  const forged = await fetch(`${API}/internal/jobs/accept`, {
    method: 'POST',
    headers: { ...auth('worker', 'ai.result.accept', { job_id: createdBody.jobId, attempt_id: randomUUID() }), 'idempotency-key': randomUUID() },
    body: JSON.stringify({
      jobId: createdBody.jobId,
      attemptId: randomUUID(),
      fencingEpoch: 1,
      leaseToken: 'not-a-real-lease-token',
      generation: 1,
      inputHash: 'ab'.repeat(32),
      ok: true,
      envelope: { invocation_id: randomUUID() },
    }),
  });
  assert.equal(forged.status, 403);
  records.push({ name: 'forged_accept_without_attempt', status: forged.status });

  const reused = token('worker', 'ai.job.claim', { job_id: createdBody.jobId });
  const firstJti = await fetch(`${API}/internal/jobs/claim`, {
    method: 'POST',
    headers: { authorization: `Bearer ${reused}`, 'content-type': 'application/json' },
    body: JSON.stringify({ jobId: createdBody.jobId, capability: 'missing' }),
  });
  const secondJti = await fetch(`${API}/internal/jobs/claim`, {
    method: 'POST',
    headers: { authorization: `Bearer ${reused}`, 'content-type': 'application/json' },
    body: JSON.stringify({ jobId: createdBody.jobId, capability: 'missing' }),
  });
  assert.equal(secondJti.status, 401);
  records.push({ name: 'jti_reuse', first: firstJti.status, second: secondJti.status });

  const widened = jwt.sign({
    scope: 'ai.billing.settle', iss: 'zhixue-worker', sub: 'svc:worker', jti: randomUUID(),
  }, process.env.WORKER_JWT_SECRET, { audience: 'zhixue-internal', expiresIn: '2m' });
  const denied = await fetch(`${API}/internal/jobs/record-settlement`, {
    method: 'POST',
    headers: { authorization: `Bearer ${widened}`, 'content-type': 'application/json' },
    body: JSON.stringify({ jobId: createdBody.jobId, invocationId: randomUUID(), amount: '1.00', key: 'nope' }),
  });
  assert.equal(denied.status, 403);
  records.push({ name: 'worker_cannot_bill', status: denied.status });

  await assert.rejects(
    (async () => {
      await ingress.query('BEGIN');
      await ingress.query(`SELECT set_config('app.tenant_id', $1, true)`, [A]);
      await ingress.query(
        `INSERT INTO zhixue.execution_attempts (tenant_id, id, job_id, fencing_epoch, lease_token_hash, lease_until)
         VALUES ($1, $2, $3, 9, 'hash', now())`,
        [A, randomUUID(), randomUUID()],
      );
      await ingress.query('COMMIT');
    })(),
    (error) => error.code === '23503',
  );
  await ingress.query('ROLLBACK');
  records.push({ name: 'fk_missing_job', rejected: true });

  const billable = await fetch(`${API}/internal/test/billable-job`, {
    method: 'POST',
    headers: { authorization: `Bearer ${tokenA}`, 'idempotency-key': `bill-${randomUUID()}` },
  });
  const billBody = await billable.json();
  assert.equal(billable.status, 201, JSON.stringify(billBody));
  const parked = await poll(tokenA, billBody.jobId);
  assert.equal(parked.status, 'awaiting_settlement');
  records.push({ name: 'unknown_auto_park', status: parked.status });

  writeFileSync('var/g1-logs/g1-results.json', JSON.stringify(records, null, 2));
  } finally {
    await app.end().catch(() => undefined);
    await ingress.end().catch(() => undefined);
  }
});

test.after(async () => {
  for (const child of [supervisor, worker, inference, api]) child?.kill('SIGKILL');
});
